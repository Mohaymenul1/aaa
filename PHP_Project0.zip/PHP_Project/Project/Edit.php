<?php

    // Get the ID from the URL
    $id = $_GET['id'];
    
    // Database connection
    $con = mysqli_connect('localhost', 'root', '', 'project1');
    
    // Fetching data from the database
    $sql = "SELECT * FROM student WHERE Id = $id";
    $result = mysqli_query($con, $sql);
    $student = mysqli_fetch_assoc($result);
    

if(isset($_POST['name'])){
    // Retrieve form data
    $name = $_POST['name'];
    $address = $_POST['address'];
    $roll = $_POST['roll'];
    $batch = $_POST['batch'];
    $semester = $_POST['semester'];
    $course = $_POST['course'];
    $gender = $_POST['gender'];
    $birthdate = $_POST['birthdate'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $color = $_POST['color'];
    // Insert data into database
    $sql = "UPDATE student SET Name='$name', Address='$address', Roll='$roll', Batch='$batch', Semester='$semester', Course='$course', Gender='$gender', Birthdate='$birthdate', Email='$email', Phone='$phone', Color='$color' WHERE Id='$id'";
    $result = mysqli_query($con, $sql);
    if($result){
        header('Location: index.php');
        echo "Record added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }
    
    // Close connection
    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Form</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Custom Styles */
    body {
      background-color: #f8f9fa;
    }
    .contact-form {
      max-width: 500px;
      margin: 0 auto;
      padding: 30px;
      background-color: #fff;
      border-radius: 8px;
      margin-top: 50px;
      box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row">
    <div class="col-md-2">
            <br>
            <a href="index.php" class="btn btn-primary">Back</a>
       </div>
      <div class="col-md-12">
        <div class="contact-form">
          <h3 class="text-center mb-2">Edit Student Information</h3>
          <form method="POST">
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" name="name" value="<?php echo $student['Name']; ?>" class="form-control" id="name" placeholder="Enter your name" required>
            </div>
            <div class="form-group">
              <label for="address">Address</label>
              <textarea class="form-control" name="address" id="address" rows="3" placeholder="Enter your address" required><?php echo $student['Address']; ?></textarea>
            </div>
            <div class="form-group">
              <label for="roll">Roll</label>
              <input type="number" name="roll" value="<?php echo $student['Roll']; ?>" class="form-control" id="roll" placeholder="Enter your roll number" required>
            </div>
            <div class="form-group">
                <label for="batch">Batch</label>
                <select name="batch" class="form-control" id="batch" required>
                    <option value="">Select Batch</option>
                    <option value="15" <?php echo ($student['Batch'] == '15') ? 'selected' : ''; ?>>15</option>
                    <option value="16" <?php echo ($student['Batch'] == '16') ? 'selected' : ''; ?>>16</option>
                    <option value="17" <?php echo ($student['Batch'] == '17') ? 'selected' : ''; ?>>17</option>
                    <option value="18" <?php echo ($student['Batch'] == '18') ? 'selected' : ''; ?>>18</option>
                </select>
                </div>
            <div class="form-group">
              <label for="semester">Semester</label>
              <select name="semester" class="form-control" id="semester" required>
                <option value="">Select Semester</option>
                <?php for($i=1; $i<=8; $i++) { ?>
                  <option value="<?php echo $i; ?>" <?php echo ($student['Semester'] == $i) ? 'selected' : ''; ?>><?php echo $i; ?></option>
                <?php } ?>
              </select>
            </div>
            <div class="form-group">
              <label for="course">Course</label>
              <select name="course" class="form-control" id="course" required>
                <option value="">Select Course</option>
                <option value="CSE" <?php echo ($student['Course'] == 'CSE') ? 'selected' : ''; ?>>CSE</option>
                <option value="CE" <?php echo ($student['Course'] == 'CE') ? 'selected' : ''; ?>>CE</option>
                <option value="EEE"<?php echo ($student['Course'] == 'EEE') ? 'selected' : ''; ?>>EEE</option>
              </select>
            </div>
            <div class="form-group">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" id="male" value="Male" <?php echo ($student['Gender'] == 'Male') ? 'checked' : ''; ?> required>
                    <label class="form-check-label" for="male">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" id="female" value="Female" <?php echo ($student['Gender'] == 'Female') ? 'checked' : ''; ?> required>
                    <label class="form-check-label" for="female">Female</label>
                </div>
            </div>
            <div class="form-group">
              <label for="birthdate">Birthdate</label>
              <input name="birthdate" type="date" value="<?php echo $student['Birthdate']; ?>" class="form-control" id="birthdate" required>
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input name="email" type="email" value="<?php echo $student['Email']; ?>" class="form-control" id="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
              <label for="phone">Phone Number</label>
              <input name="phone" type="text" value="<?php echo $student['Phone']; ?>" class="form-control" id="phone" placeholder="Enter your phone number" pattern="[0-9]{11}" title="Please enter 11 digits" required>
            </div>
            <div class="form-group">
              <label for="image">Image</label>
              <input type="file" class="form-control-file" id="image">
            </div>
            <div class="form-group">
                <label for="Color">What is your favourite Color?</label>
                <select name="color" class="form-control" id="color" required>
                  <option value="">Select Color</option>
                  <option value="Red" <?php echo ($student['Color'] == 'Red') ? 'selected' : ''; ?>>Red</option>
                  <option value="Green" <?php echo ($student['Color'] == 'Green') ? 'selected' : ''; ?>>Green</option>
                  <option value="Blue" <?php echo ($student['Color'] == 'Blue') ? 'selected' : ''; ?>>Blue</option>
                  <option value="Yellow" <?php echo ($student['Color'] == 'Yellow') ? 'selected' : ''; ?>>Yellow</option>
                  <option value="Orange" <?php echo ($student['Color'] == 'Orange') ? 'selected' : ''; ?>>Orange</option>
                </select>
            </div>
              
            <button type="submit" class="btn btn-primary">Update</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS and dependencies -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    // Function to generate a random math problem
    function generateCaptcha() {
      var num1 = Math.floor(Math.random() * 10) + 1; // Generate a random number between 1 and 10
      var num2 = Math.floor(Math.random() * 10) + 1; // Generate a random number between 1 and 10
      var operation = ['+', '-', '*'][Math.floor(Math.random() * 3)]; // Choose a random operation
      var result;
      
      // Perform the operation
      switch (operation) {
        case '+':
          result = num1 + num2;
          break;
        case '-':
          result = num1 - num2;
          break;
        case '*':
          result = num1 * num2;
          break;
      }
      
      // Display the math problem
      document.getElementById('captcha-question').textContent = num1 + ' ' + operation + ' ' + num2 + ' =';
      // Store the correct result in a hidden input field
      document.getElementById('captcha-result').value = result;
    }

    // Generate the captcha when the page loads
    window.onload = function() {
      generateCaptcha();
    };
  </script>
</body>
</html>
