<?php
// Get the ID from the URL
$id = $_GET['id'];
    
// Database connection
$con = mysqli_connect('localhost', 'root', '', 'project1');
$sql = "DELETE FROM student WHERE Id = $id";
$result = mysqli_query($con, $sql);

header('Location: index.php');

?>