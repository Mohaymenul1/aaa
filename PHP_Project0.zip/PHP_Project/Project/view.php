<?php
// Check if 'id' parameter exists in the URL
if(isset($_GET['id'])) {
    // Get the ID from the URL
    $id = $_GET['id'];
    
    // Database connection
    $con = mysqli_connect('localhost', 'root', '', 'project1');
    
    // Check connection
    if (mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      exit();
    }
    
    // Fetching data from the database
    $sql = "SELECT * FROM student WHERE Id = $id";
    $result = mysqli_query($con, $sql);
    $student = mysqli_fetch_assoc($result);
    
    // Close the database connection
    mysqli_close($con);
} else {
    // Redirect if 'id' parameter is not provided
    header("Location: error.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Information</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Custom Styles */
    body {
      background-color: #f8f9fa;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row clearfix">
    <div class="col-md-2">
            <br>
            <a href="index.php" class="btn btn-primary">Back</a>
       </div>
      <div class="col-md-8">
        <h1 class="mt-5">Student Information</h1>
        <table class="table">
          <!-- <tr>
            <th class="text-right">ID</th>
            <td><?php echo $student['Id']; ?></td>
          </tr> -->
          <tr>
            <th class="text-right">Name</th>
            <td><?php echo $student['Name']; ?></td>
          </tr>
          <tr>
            <th class="text-right">Roll</th>
            <td><?php echo $student['Roll']; ?></td>
          </tr>
          <tr>
            <th class="text-right">Batch</th>
            <td><?php echo $student['Batch']; ?></td>
          </tr>
          <tr>
            <th class="text-right">Semester</th>
            <td><?php echo $student['Semester']; ?></td>
          </tr>
          <tr>
            <th class="text-right">Course</th>
            <td><?php echo $student['Course']; ?></td>
          </tr>
          <tr>
            <th class="text-right">Email</th>
            <td><?php echo $student['Email']; ?></td>
          </tr>
          <tr>
            <th class="text-right">Phone Number</th>
            <td><?php echo $student['Phone']; ?></td>
          </tr>
          <tr>
            <th class="text-right">Birthdate</th>
            <td><?php echo $student['Birthdate']; ?></td>
          </tr>
          <tr>
            <th class="text-right">Color</th>
            <td><?php echo $student['Color']; ?></td>
          </tr>
          <!-- Add other fields here -->
        </table>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS and dependencies -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    // Function to generate a random math problem
    function generateCaptcha() {
      var num1 = Math.floor(Math.random() * 10) + 1; // Generate a random number between 1 and 10
      var num2 = Math.floor(Math.random() * 10) + 1; // Generate a random number between 1 and 10
      var operation = ['+', '-', '*'][Math.floor(Math.random() * 3)]; // Choose a random operation
      var result;
      
      // Perform the operation
      switch (operation) {
        case '+':
          result = num1 + num2;
          break;
        case '-':
          result = num1 - num2;
          break;
        case '*':
          result = num1 * num2;
          break;
      }
      
      // Display the math problem
      document.getElementById('captcha-question').textContent = num1 + ' ' + operation + ' ' + num2 + ' =';
      // Store the correct result in a hidden input field
      document.getElementById('captcha-result').value = result;
    }

    // Generate the captcha when the page loads
    window.onload = function() {
      generateCaptcha();
    };
  </script>
</body>
</html>
